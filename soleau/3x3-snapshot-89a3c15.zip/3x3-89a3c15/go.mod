module scoreboard3x3

go 1.24

require github.com/gorilla/websocket v1.5.1

require golang.org/x/net v0.17.0 // indirect
